<!DOCTYPE HTML>
<html>
<body>
<a href="./index.html">=home=</a>
<a href="./msg_main.php">=leave a message=</a>
<a href="./about.html">=about=</a>
</br>
<?php
$con=mysql_connect("localhost","root","2025");
mysql_select_db("my_db", $con);
$n=$_GET['name'];
$s=$_GET['subject'];
$m=$_GET['message'];
$d=date("Y-m-d")." ".date("H").":".date("i").":".date("s");

$num=1;
$result = mysql_query("SELECT * FROM msg");
while($row = mysql_fetch_array($result))
{
	$num++;
}

$sql="INSERT INTO msg (id,name,subject,message,publishtime)
VALUES('$num','$n','$s','$m','$d')";
if(mysql_query($sql,$con))
{
	echo "<h2>Message send successfully</h2></br>";
	echo '<a href="./msg_main.php">go back</a></br>';
}
else
{
	echo "<h2>Something unpleasant happened:</br>".mysql_error()."</br>Please try again later.</h2></br>";
	echo '<a href="./msg_main.php">go back</a></br>';
}
mysql_close($con);
echo " end";
?>
</body>
</html>