<?php
$con=mysql_connect("localhost","root","2025");
if(!$con)
{
	die('could not connect:'.mysql_error());
}

mysql_select_db("my_db", $con);
if($_GET["id"]=="config")
{
	echo "12345";
}
if($_GET["id"]=="init")
{
	mysql_query("CREATE DATABASE my_db",$con);
	$sql2 = "CREATE TABLE chat
	(
	id int,
	username varchar(15),
	message varchar(100),
	publishtime varchar(20)
	)";
	mysql_query($sql2,$con);
	$sql2 = "CREATE TABLE user
	(
	id int,
	username varchar(15),
	publishtime varchar(20)
	)";
	mysql_query($sql2,$con);
	$sql2 = "CREATE TABLE msg
	(
	id int,
	name varchar(20),
	subject varchar(20),
	message varchar(100),
	publishtime varchar(20)
	)";
	mysql_query($sql2,$con);
}

if($_GET["id"]=="addchat")
{
	$datedate=date("Y-m-d")." ".date("H").":".date("i").":".date("s");
	$sql3="INSERT INTO chat (username,message,publishtime)
	VALUES('$_GET[username]','htmlspecialchars($_GET[message])',$datedate)";
	mysql_query($sql3,$con);
}

if($_GET["id"]=="adduser")
{
	$num=1;
	$result = mysql_query("SELECT * FROM user");
	while($row = mysql_fetch_array($result))
	{
		$num=$num+1;
	}
	$usr=htmlspecialchars($_GET[username]);
	$datedate=date("Y-m-d")." ".date("H").":".date("i").":".date("s");
	$sql4="INSERT INTO user (id,username,publishtime)
	VALUES('$num','$usr','$datedate')";
	mysql_query($sql4,$con);
	echo $num;
}

if($_GET["id"]=="showuser")
{
$result = mysql_query("SELECT * FROM user");
while($row = mysql_fetch_array($result))
  {
  echo $row['id']." ".$row['username'] ." ".$row['publishtime'];
  echo "</br>";
  }
}
if($_GET["id"]=="showchat")
{
$result = mysql_query("SELECT * FROM user");
while($row = mysql_fetch_array($result))
  {
  echo $row['id']." ".$row['username'] ." ".$row['publishtime'];
  echo "</br>";
  }
}
if($_GET["id"]=="showmsg")
{
$result = mysql_query("SELECT * FROM msg");
while($row = mysql_fetch_array($result))
  {
  echo "-----------------------</br>";
  echo $row['id'].": ".$row['name']."</br>".$row['subject'] ."</br>".$row['message']."</br>".$row['publishtime'];
  echo "</br>-----------------------</br>";
  }
}
if($_GET["id"]=="command")
{
	echo mysql_query($_GET["command"]);
}

if($_GET["id"]=="del")
{
	mysql_query("DELETE FROM user WHERE id='$_GET[userid]'");
}
















mysql_close($con);
echo " end";
?>
